import { SDKRegistrationConfig } from '@opentelemetry/sdk-trace-base';
import { NodeTracerConfig } from '@opentelemetry/sdk-trace-node';
declare global {
    function configureSdkRegistration(defaultSdkRegistration: SDKRegistrationConfig): SDKRegistrationConfig;
    function configureTracer(defaultConfig: NodeTracerConfig): NodeTracerConfig;
}
//# sourceMappingURL=adot-extension.d.ts.map