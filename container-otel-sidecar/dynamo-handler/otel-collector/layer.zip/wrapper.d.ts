import { NodeTracerConfig, NodeTracerProvider } from '@opentelemetry/sdk-trace-node';
import { SDKRegistrationConfig } from '@opentelemetry/sdk-trace-base';
import { Instrumentation } from '@opentelemetry/instrumentation';
import { AwsLambdaInstrumentationConfig } from '@opentelemetry/instrumentation-aws-lambda';
declare global {
    function configureTracerProvider(tracerProvider: NodeTracerProvider): void;
    function configureTracer(defaultConfig: NodeTracerConfig): NodeTracerConfig;
    function configureSdkRegistration(defaultSdkRegistration: SDKRegistrationConfig): SDKRegistrationConfig;
    function configureLambdaInstrumentation(config: AwsLambdaInstrumentationConfig): AwsLambdaInstrumentationConfig;
    function configureInstrumentations(): Instrumentation[];
}
//# sourceMappingURL=wrapper.d.ts.map