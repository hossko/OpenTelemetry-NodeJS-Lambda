"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@opentelemetry/core");
const propagator_b3_1 = require("@opentelemetry/propagator-b3");
const id_generator_aws_xray_1 = require("@opentelemetry/id-generator-aws-xray");
const propagator_aws_xray_1 = require("@opentelemetry/propagator-aws-xray");
if (!process.env.OTEL_PROPAGATORS) {
    global.configureSdkRegistration = (config) => {
        return Object.assign(Object.assign({}, config), { propagator: new core_1.CompositePropagator({
                propagators: [
                    new propagator_aws_xray_1.AWSXRayPropagator(),
                    new core_1.W3CTraceContextPropagator(),
                    new propagator_b3_1.B3Propagator(),
                    new propagator_b3_1.B3Propagator({ injectEncoding: propagator_b3_1.B3InjectEncoding.MULTI_HEADER }),
                ],
            }) });
    };
}
global.configureTracer = (config) => {
    return Object.assign(Object.assign({}, config), { idGenerator: new id_generator_aws_xray_1.AWSXRayIdGenerator() });
};
//# sourceMappingURL=adot-extension.js.map